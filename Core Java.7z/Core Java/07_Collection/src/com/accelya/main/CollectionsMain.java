package com.accelya.main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class CollectionsMain {
	public static void main(String[] args) {
		// ArrayListDemo();
		// HashSetDemo();
		// TreeSetDemo();
		HashMapDemo();
	}

	public static void ArrayListDemo() {
		List<Integer> numbersList = new ArrayList<>(20);
		System.out.println("Size :: " + numbersList.size());
		numbersList.add(101);
		System.out.println("Size :: " + numbersList.size());
		numbersList.add(110);
		numbersList.add(120);
		numbersList.add(11);
		numbersList.add(4);
		numbersList.add(120);
		numbersList.add(510);
		numbersList.add(10);
		numbersList.add(null);
		System.out.println("Size :: " + numbersList.size());
//		 System.out.println(numbersList);
		for (Integer i : numbersList) {
			System.out.println(i);
		}
	}

	public static void HashSetDemo() {
		Set<Integer> numbersSet = new HashSet<>();
		numbersSet.add(10);
		numbersSet.add(20);
		numbersSet.add(10);
		numbersSet.add(15);
		numbersSet.add(null);
		numbersSet.add(30);
		numbersSet.add(null);
		System.out.println(numbersSet);
	}

	public static void TreeSetDemo() {
		Set<Integer> numbersSet = new TreeSet<>();
		numbersSet.add(10);
		numbersSet.add(20);
		numbersSet.add(10);
		numbersSet.add(15);
		numbersSet.add(30);
		System.out.println(numbersSet);
	}

	public static void HashMapDemo() {
		Map<Integer, String> employeeMap = new HashMap<>();
		employeeMap.put(1, "Shivam");
		employeeMap.put(2, "Vishal");
		employeeMap.put(11, "Sahil");
		employeeMap.put(13, "Hussain");
		employeeMap.put(15, "Suman");
		employeeMap.put(23, "Jitendra");
		employeeMap.put(21, "Ayush");
		employeeMap.put(61, "Utkarsh");
		employeeMap.put(14, "Ahamad");
		employeeMap.put(14, "Ahamad Ansari");
		employeeMap.put(null, null);
		employeeMap.put(null, "Vivek");

		System.out.println(employeeMap);
	}

	public static void TreeMapDemo() {
		Map<Integer, String> employeeMap = new TreeMap<>();
		employeeMap.put(1, "Shivam");
		employeeMap.put(2, "Vishal");
		employeeMap.put(11, "Sahil");
		employeeMap.put(13, "Hussain");
		employeeMap.put(15, "Suman");
		employeeMap.put(23, "Jitendra");
		employeeMap.put(21, "Ayush");
		employeeMap.put(61, "Utkarsh");
		employeeMap.put(14, "Ahamad");
		employeeMap.put(14, "Ahamad Ansari");
//		employeeMap.put(null, null);
//		employeeMap.put(null, "Vivek");

		System.out.println(employeeMap);
	}

}
