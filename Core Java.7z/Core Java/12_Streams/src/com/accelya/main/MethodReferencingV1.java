package com.accelya.main;

public class MethodReferencingV1 {
	public static void main(String[] args) {
		new Thread(() -> printMessage()).start();

		System.out.println();

		new Thread(MethodReferencingV1::printMessage).start();
	}

	public static void printMessage() {
		System.out.println("Hello From printMessage");
	}
}
