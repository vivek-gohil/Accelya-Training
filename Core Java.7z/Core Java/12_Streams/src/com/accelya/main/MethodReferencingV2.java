package com.accelya.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.accelya.main.domain.Person;

public class MethodReferencingV2 {
	public static void main(String[] args) {
		Person[] persons = { new Person("Vivek", "Gohil", 33), new Person("Trupti", "Acharekar", 38),
				new Person("Gurubux", "Gill", 26), new Person("Samrth", "Patil", 6) };

		List<Person> people = Arrays.asList(persons);

		Collections.sort(people, (p1, p2) -> p1.getLastName().compareTo(p2.getLastName()));

		printConditionally(people, p -> true, new Consumer<Person>() {
			@Override
			public void accept(Person p) {
				System.out.println(p);
			}

		});
		printConditionally(people, p -> true, p -> System.out.println(p));

		printConditionally(people, p -> true, System.out::println);

//		printConditionally(people, p -> true, p -> System.out.println(p.getFirstName()));
//		printConditionally(people, p -> true, p -> System.out.println(p.getLastName()));

	}

	public static void printConditionally(List<Person> people, Predicate<Person> condition, Consumer<Person> consumer) {
		for (Person person : people) {
			if (condition.test(person)) {
				consumer.accept(person);
			}
		}
	}
}
