package com.accelya.main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StreamsMapMain {
	public static void main(String[] args) {
		List<String> alphabets = Arrays.asList("a", "b", "c", "d", "e");

		List<String> alphabetsUpper = new ArrayList<>();

		for (String alphabet : alphabets) {
			alphabetsUpper.add(alphabet.toUpperCase());
		}

		alphabetsUpper = alphabets.stream().map(new Function<String, String>() {

			@Override
			public String apply(String t) {
				return t.toUpperCase();
			}
		}).collect(Collectors.toList());

		alphabetsUpper = alphabets.stream().map(t -> t.toUpperCase()).collect(Collectors.toList());

	}
}
