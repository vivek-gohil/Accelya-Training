package com.accelya.main;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

public class StreamsFilterMain {
	public static void main(String[] args) {
		List<String> names = Arrays.asList("Vivek", "Bahubali", "Trupti", "Samarth");

		// print all , Bahubali
		for (String name : names) {
			if (!name.equals("Bahubali")) {
				System.out.println(name);
			}
		}

		names.stream().filter(new Predicate<String>() {
			@Override
			public boolean test(String name) {
				return !name.equals("Bahubali");
			}
		}).forEach(new Consumer<String>() {
			@Override
			public void accept(String name) {
				System.out.println(name);
			}
		});

		names.stream().filter(name -> !name.equals("Bahubali")).forEach(name -> System.out.println(name));

		names.stream().filter(name -> !name.equals("Bahubali")).forEach(System.out::println);

		names.stream().filter(StreamsFilterMain::isNotBahubali).forEach(System.out::println);

		System.out.println("Multiple Conditions");
		names.stream().filter(name -> !name.equals("Bahubali") && !name.equals("Samarth")).forEach(System.out::println);
	}

	private static boolean isNotBahubali(String name) {
		return !name.equals("Bahubali") && !name.equals("Samarth");
	}

}
