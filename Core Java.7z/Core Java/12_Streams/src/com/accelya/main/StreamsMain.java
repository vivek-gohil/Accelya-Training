package com.accelya.main;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.accelya.main.domain.Person;

public class StreamsMain {
	public static void main(String[] args) {
		List<String> list = Arrays.asList("A", "z", "D", "w", "e", "d", "c", "a", "F", "E");
		System.out.println(list);
		List<String> sortedList = list.stream().sorted().collect(Collectors.toList());

		System.out.println();

		Person[] persons = { new Person("Vivek", "Gohil", 33), new Person("Trupti", "Acharekar", 38),
				new Person("Gurubux", "Gill", 26), new Person("Samrth", "Patil", 6) };

		List<Person> people = Arrays.asList(persons);

		List<Person> sortedPeopleByFirstName = people.stream()
				.sorted((p1, p2) -> p1.getFirstName().compareTo(p2.getFirstName())).collect(Collectors.toList());

		System.out.println(sortedPeopleByFirstName);

//		List<Person> sortedPeopleByAge = people.stream().sorted((p1, p2) -> p1.getAge() - p2.getAge())
//				.collect(Collectors.toList());
//
//		System.out.println(sortedPeopleByAge);

	}
}
