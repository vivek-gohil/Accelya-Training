package com.accelya.main;

import java.util.Arrays;
import java.util.function.IntBinaryOperator;

public class StreamsReduceMain {
	public static void main(String[] args) {
		int[] numbers = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		int sum = 0;
		for (int i : numbers) {
			sum += i;
		}
		System.out.println(sum);

		sum = Arrays.stream(numbers).reduce(new IntBinaryOperator() {

			@Override
			public int applyAsInt(int left, int right) {
				System.out.println("left :: " + left + " right :: " + right);
				return left + right;
			}
		}).getAsInt();

		sum = Arrays.stream(numbers).reduce((l, r) -> l + r).getAsInt();

		sum = Arrays.stream(numbers).reduce(Integer::sum).getAsInt();

		System.out.println(sum);

		String s1 = new String("Hi");
		String s2 = new String("Hi");

		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
		System.out.println(s1 == s2);
	}
}
