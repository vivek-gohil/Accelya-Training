package com.accelya.main.domain;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Calculations {
	private double number1, number2, result;
	private Scanner scanner = new Scanner(System.in);

	public void accept() {
		try {
			System.out.println("Enter Number 1 :: ");
			number1 = scanner.nextDouble();
			System.out.println("Enter Number 2 :: ");
			number2 = scanner.nextDouble();
		} catch (InputMismatchException e) {
			System.out.println("Exception in code");
			System.out.println(e.getMessage());
		} catch (Exception e) {
			System.out.println("Exception in code");
			System.out.println(e.getMessage());
		} finally {
			System.out.println("end of accept()!!");
			scanner.close();
		}
	}

	public void calculate() {
		System.out.println("Calculating Result");
		result = number1 / number2;
	}

	public void display() {
		System.out.println("Result :: " + result);
	}

}
