package com.accelya.main.exceptions;

public class InvalidSalaryException extends Exception {
	public InvalidSalaryException() {
		System.out.println("Invalid Employee Salary!!");
	}

	@Override
	public String getMessage() {
		return "Please enter valid salary (> 1000) ";
	}
}
