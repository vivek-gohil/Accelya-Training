package com.accelya.main;

import com.accelya.main.domain.Employee;
import com.accelya.main.exceptions.InvalidSalaryException;

public class EmployeeMain {
	public static void main(String[] args) {
		
		// Unchecked
//		Employee employee = null;
//		try {
//			employee = new Employee(101, "Vivek Gohil", 900);
//		} catch (InvalidSalaryException e) {
//			System.out.println(e.getMessage());
//		}
//		System.out.println(employee);

		//Checked 
		try {
			Employee employee = new Employee(101, "Vivek Gohil", 900);
		} catch (InvalidSalaryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Done !!");
	}
}
