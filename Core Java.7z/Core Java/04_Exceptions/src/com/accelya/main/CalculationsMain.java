package com.accelya.main;

import com.accelya.main.domain.Calculations;

public class CalculationsMain {
	public static void main(String[] args) {
		Calculations calculations = new Calculations();
		calculations.accept();
		calculations.calculate();
		calculations.display();
	}
}
