package com.accelya.main.threads;

public class ThreadOne extends Thread {
	@Override
	public void run() {
		System.out.println("We are in ThreadOne");
	}
}
