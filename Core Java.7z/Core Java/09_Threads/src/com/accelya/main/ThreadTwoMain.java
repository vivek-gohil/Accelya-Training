package com.accelya.main;

import com.accelya.main.threads.ThreadTwo;

public class ThreadTwoMain {
	public static void main(String[] args) {
		System.out.println("We are in main");
		System.out.println("main is creating child thread");
		ThreadTwo threadTwo = new ThreadTwo();
		Thread thread = new Thread(threadTwo);
		System.out.println(thread);
		thread.setPriority(10);
		thread.start();
		for (int i = 0; i < 1000; i++) {
			System.out.println("main::" + i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("main end");
	}
}
