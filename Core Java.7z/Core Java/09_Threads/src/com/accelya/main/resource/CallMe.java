package com.accelya.main.resource;

public class CallMe {
	public synchronized void call(String message) {
		try {
			System.out.print("[");
			Thread.sleep(1000);
			System.out.print(message);
			Thread.sleep(1000);
			System.out.print("]");
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}
	}
}
