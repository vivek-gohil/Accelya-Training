package com.accelya.main;

import com.accelya.main.resource.CallMe;
import com.accelya.main.threads.Caller;

public class AsyncCaller {
	public static void main(String[] args) {
		CallMe callMe = new CallMe();

		Caller shantanu = new Caller(callMe, "Hi.. How r u?");
		Caller abhishek = new Caller(callMe, "Hi.. Where r u?");

		Thread t1 = new Thread(shantanu);
		Thread t2 = new Thread(abhishek);

		t1.start();
		t2.start();

	}
}
