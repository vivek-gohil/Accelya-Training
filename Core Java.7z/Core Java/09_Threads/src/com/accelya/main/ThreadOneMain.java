package com.accelya.main;

import com.accelya.main.threads.ThreadOne;

public class ThreadOneMain {
	public static void main(String[] args) {

		Thread thread = new ThreadOne();
		thread.start();
	}
}
