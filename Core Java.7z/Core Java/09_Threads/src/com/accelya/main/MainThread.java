package com.accelya.main;

public class MainThread {
	public static void main(String[] args) {
		Thread currentThread = Thread.currentThread();
		System.out.println(currentThread);
		currentThread.setName("mainThread");
		System.out.println(currentThread);
	}
}
