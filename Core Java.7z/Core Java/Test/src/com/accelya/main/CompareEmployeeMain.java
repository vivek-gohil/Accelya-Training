package com.accelya.main;

import java.util.Arrays;

import com.accelya.main.domain.Employee;

public class CompareEmployeeMain {
	public static void main(String[] args) {
		Employee[] employees = new Employee[4];
		Employee employee1 = new Employee(3, "Test 3", 1000);
		Employee employee2 = new Employee(2, "Test 2", 1000);
		Employee employee3 = new Employee(1, "Test 1", 1000);
		Employee employee4 = new Employee(4, "Test 4", 1000);

		employees[0] = employee1;
		employees[1] = employee2;
		employees[2] = employee3;
		employees[3] = employee4;

		Arrays.sort(employees);

		for (Employee emp : employees) {
			System.out.println(emp);
		}
	}
}
