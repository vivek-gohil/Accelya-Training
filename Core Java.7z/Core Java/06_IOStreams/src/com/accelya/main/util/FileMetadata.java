package com.accelya.main.util;

import java.io.File;
import java.util.Date;

public class FileMetadata {
	public void printFileMetadata(File file) {
		if (file.exists()) {
			System.out.println("File Name :: " + file.getName());
			System.out.println("Path :: " + file.getAbsolutePath());
			System.out.println("Size :: " + file.length() + " bytes");
			System.out.println("Is File ? ::  " + file.isFile());
			System.out.println("Is Folder ? :: " + file.isDirectory());

			Date date = new Date(file.lastModified());
			System.out.println("Last Modified Time :: " + date);
			System.out.println("Can Read :: " + file.canRead());
			System.out.println("Can Execute :: " + file.canExecute());
			System.out.println("Can Write :: " + file.canWrite());
		} else {
			System.out.println("Not exists");
		}
	}
}
