package com.accelya.main.util;

import java.io.File;
import java.io.IOException;
import java.io.Reader;

public class FileReaderUtil {
	private Reader reader;
	private char[] data;

	public FileReaderUtil(Reader reader, File file) {
		this.reader = reader;
		data = new char[(int) file.length()];
	}

	public char[] readFile() throws IOException {
		reader.read(data);
		return data;
	}

}
