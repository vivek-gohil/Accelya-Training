package com.accelya.main.util;

import java.io.IOException;
import java.io.OutputStream;

public class FileOutputStreamUtil {
	private OutputStream outputStream;

	public FileOutputStreamUtil(OutputStream outputStream) {
		this.outputStream = outputStream;
	}

	public void writeFile(byte[] data) throws IOException {
		outputStream.write(data);
	}

}
