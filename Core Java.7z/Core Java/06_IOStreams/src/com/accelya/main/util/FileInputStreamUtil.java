package com.accelya.main.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

public class FileInputStreamUtil {
	private InputStream inputStream;
	private byte[] data;

	public FileInputStreamUtil(InputStream inputStream, File file) {
		this.inputStream = inputStream;
		data = new byte[(int) file.length()];
	}

	public byte[] readFile() throws IOException {
		inputStream.read(data);
		return data;
	}

}
