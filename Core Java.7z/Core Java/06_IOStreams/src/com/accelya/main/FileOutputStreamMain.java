package com.accelya.main;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import com.accelya.main.util.FileOutputStreamUtil;

public class FileOutputStreamMain {
	public static void main(String[] args) {
		String data = "File IO is simple!!";

		File file = new File("d:/demo/data.txt");
		FileOutputStream fileOutputStream = null;
		FileOutputStreamUtil fileOutputStreamUtil = null;
		try {
			fileOutputStream = new FileOutputStream(file,true);
			fileOutputStreamUtil = new FileOutputStreamUtil(fileOutputStream);
			fileOutputStreamUtil.writeFile(data.getBytes());
			System.out.println("Please check your file");
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				fileOutputStream.flush();
				fileOutputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
