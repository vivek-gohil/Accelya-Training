package com.accelya.main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import com.accelya.main.util.FileReaderUtil;

public class FileReaderMain {
	public static void main(String[] args) {
		File file = new File("d:/demo/test.txt");
		BufferedReader bufferedReader = null;
		FileReader fileReader = null;
		FileReaderUtil fileReaderUtil = null;

		try {
			fileReader = new FileReader(file);
			bufferedReader = new BufferedReader(fileReader);
			fileReaderUtil = new FileReaderUtil(bufferedReader, file);
			char[] data = fileReaderUtil.readFile();
			for (char c : data) {
				System.out.print(c);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fileReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
