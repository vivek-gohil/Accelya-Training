package com.accelya.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import com.accelya.main.util.FileInputStreamUtil;

public class FileInputStreamMain {
	public static void main(String[] args) {
		File file = new File("d:/demo/test.txt");
		FileInputStream fileInputStream;
		try {
			fileInputStream = new FileInputStream(file);
			FileInputStreamUtil fileInputStreamUtil = 
					new FileInputStreamUtil(fileInputStream, file);

			byte[] data = fileInputStreamUtil.readFile();
			for (byte b : data) {
				System.out.print((char) b);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}
}
