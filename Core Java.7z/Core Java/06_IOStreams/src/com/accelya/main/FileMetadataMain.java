package com.accelya.main;

import java.io.File;
import java.util.Scanner;

import com.accelya.main.util.FileMetadata;

public class FileMetadataMain {
	public static void main(String[] args) {
		String path;
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("Enter Path");
		path = scanner.next();
		File file = new File(path);
		FileMetadata fileMetadata = new FileMetadata();
		fileMetadata.printFileMetadata(file);
		
		scanner.close();
	}
}
