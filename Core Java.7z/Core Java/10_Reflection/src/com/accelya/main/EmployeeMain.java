package com.accelya.main;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

import com.accelya.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {

		// Employee employee = new Employee(101, "Vivek Gohil", 1000);

		// load class details using reflection
		// Class employeeClass = employee.getClass();

		Class employeeClass = Employee.class;

		// Print the class name
		System.out.println("The name of class is :: " + employeeClass.getName());
		System.out.println("The package name :: " + employeeClass.getPackageName());

		// Load all constrcutor
		Constructor[] allConstructors = employeeClass.getConstructors();
		for (Constructor constructor : allConstructors) {
			System.out.println(constructor.getName());
			Parameter[] parameters = constructor.getParameters();
			for (Parameter parameter : parameters) {
				System.out.println(parameter.getName());
				System.out.println(parameter.getType());
			}
		}

		System.out.println();
		// Methods
		Method[] allMethods = employeeClass.getDeclaredMethods();
		for (Method method : allMethods) {
			System.out.println(method);

//			if (method.getName().equals("setEmployeeId")) {
//				try {
//					method.invoke(employee, 101);
//				} catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
//					e.printStackTrace();
//				}
//			}
		}
		System.out.println();

		Field[] allVariables = employeeClass.getDeclaredFields();
		for (Field field : allVariables) {
			System.out.println(field);
		}

	}
}
