package com.accelya.main.domain;

public class Current {

}
