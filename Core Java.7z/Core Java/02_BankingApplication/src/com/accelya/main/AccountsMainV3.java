package com.accelya.main;

import java.util.Scanner;

import com.accelya.main.domain.Accounts;

public class AccountsMainV3 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int accountNumber;
		String name;
		double balance;
		int choice;
		double amount;
		boolean result;
		String continueChoice;

		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();

		scanner.nextLine();

		System.out.println("Enter Name");
		name = scanner.nextLine();

		System.out.println("Enter Balance");
		balance = scanner.nextDouble();

		System.out.println("Account Details");
		Accounts accounts = new Accounts(accountNumber, name, balance);

		System.out.println("Account Number :: " + accounts.getAccountNumber());
		System.out.println("Name :: " + accounts.getName());
		System.out.println("Balance ::  " + accounts.getBalance());
		do {
			System.out.println("Menu");
			System.out.println("1. Withdraw");
			System.out.println("2. Deposit");
			System.out.println("3. Balance");
			System.out.println("4. Exit");
			System.out.println("Enter your choice");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Amount to withdraw");
				amount = scanner.nextDouble();
				result = accounts.withdraw(amount);
				if (result) {
					System.out.println("Transaction Successfull");
					System.out.println("Balance :: " + accounts.getBalance());
				} else {
					System.out.println("Transaction Failed!!");
					System.out.println("Balance :: " + accounts.getBalance());
				}
				break;
			case 2:
				System.out.println("Enter Amount to deposit");
				amount = scanner.nextDouble();
				result = accounts.deposit(amount);
				if (result) {
					System.out.println("Transaction Successfull");
					System.out.println("Balance :: " + accounts.getBalance());
				} else {
					System.out.println("Transaction Failed!!");
					System.out.println("Balance :: " + accounts.getBalance());
				}
				break;
			case 3:
				System.out.println("Balance :: " + accounts.getBalance());
				break;
			case 4:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Choice");
				break;
			}
			System.out.println("Do you want to continue ??");
			continueChoice = scanner.next();
		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();

	}
}
