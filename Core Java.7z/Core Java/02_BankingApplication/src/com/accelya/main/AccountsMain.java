package com.accelya.main;

import com.accelya.main.domain.Accounts;

public class AccountsMain {
	public static void main(String[] args) {
		Accounts accounts = new Accounts(101, "Vivek Gohil", 1000);

		Accounts accounts2 = new Accounts();
		accounts2.setAccountNumber(102);
		accounts2.setName("Abhishek");
		accounts2.setBalance(1000);

		System.out.println(accounts.getAccountNumber());
		System.out.println(accounts.getName());
		System.out.println(accounts.getBalance());
		
		System.out.println("------------------------");
		System.out.println(accounts2.getAccountNumber());
		System.out.println(accounts2.getName());
		System.out.println(accounts2.getBalance());
		
	}
}
