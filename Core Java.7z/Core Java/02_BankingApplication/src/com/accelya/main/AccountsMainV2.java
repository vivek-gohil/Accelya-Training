package com.accelya.main;

import java.util.Scanner;

import com.accelya.main.domain.Accounts;

public class AccountsMainV2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int accountNumber;
		String name;
		double balance;

		System.out.println("Enter account number");
		accountNumber = scanner.nextInt();

		scanner.nextLine();
		
		System.out.println("Enter Name");
		name = scanner.nextLine();

		System.out.println("Enter Balance");
		balance = scanner.nextDouble();

		System.out.println("Account Details");
		Accounts accounts = new Accounts(accountNumber, name, balance);

		System.out.println("Account Number :: " + accounts.getAccountNumber());
		System.out.println("Name :: " + accounts.getName());
		System.out.println("Balance ::  " + accounts.getBalance());
		
		scanner.close();
	}

}
