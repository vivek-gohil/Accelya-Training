package com.accelya.main;

import com.accelya.main.domain.Employee;

public class EmployeeMain {
	public static void main(String[] args) {
		// create 5 employee objects
		Employee employee = new Employee(101, "Abhishek", 1000);
		Employee employee2 = new Employee(102, "Ashutosh", 1000);
		Employee employee3 = new Employee(103, "Vivek", 1000);
		Employee employee4 = new Employee(104, "Zaid", 1000);
		Employee employee5 = new Employee(105, "Pravin", 1000);

		Employee[] employees = { employee, employee2, employee3, employee4, employee5 };

		for (Employee emp : employees) {
			System.out.println(emp.toString());
//			System.out.println(emp.getEmployeeId());
//			System.out.println(emp.getName());
//			System.out.println(emp.getSalary());
			System.out.println();
		}
		
		System.out.println(employee);
		
	}
}
