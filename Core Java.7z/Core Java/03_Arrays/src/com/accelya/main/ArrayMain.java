package com.accelya.main;

public class ArrayMain {
	public static void main(String[] args) {
		int myArray[] = new int[5];

		myArray[0] = 12;
		myArray[1] = 122;
		myArray[2] = 11;
		myArray[3] = 21;
		myArray[4] = 53;

		// Using for each loop ( read only loop)
		for (int i : myArray) {
			System.out.println(i);
		}

		int anotherArray[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		// Using for each loop ( read only loop)
		for (int i : anotherArray) {
			System.out.println(i);
		}

	}
}
