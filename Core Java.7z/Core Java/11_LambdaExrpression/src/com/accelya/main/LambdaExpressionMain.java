package com.accelya.main;

abstract class MyClass {
	public abstract void show();
}

public class LambdaExpressionMain {
	static MyClass myClass;

	public static void main(String[] args) {
		myClass = new MyClass() {
			@Override
			public void show() {

			}
		};

		Runnable runnable = new Runnable() {

			@Override
			public void run() {
				System.out.println("My Thread is running");
			}
		};

		Thread t1 = new Thread(runnable);
		t1.start();

		Runnable runnable2 = () -> {
			System.out.println("My Thread 2 is running");
		};

		Thread t2 = new Thread(runnable2);
		t2.start();

		Thread t3 = new Thread(() -> {
			System.out.println("My thread 3 is running");
		});
		t3.start();

		System.out.println();

//		MyInterface myInterface = new MyInterface() {
//			
//			@Override
//			public void display() {
//				System.out.println("hi");
//			}
//		};

		MyInterface myInterface = () -> System.out.println("Hi");

		myInterface.display();

	}
}
