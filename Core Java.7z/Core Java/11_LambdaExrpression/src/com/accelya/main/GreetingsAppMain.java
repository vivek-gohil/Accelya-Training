package com.accelya.main;

import com.accelya.main.domain.Greet;
import com.accelya.main.domain.GreetingsApp;

public class GreetingsAppMain {
	public static void main(String[] args) {

//		Greet goodMorningGreet = new Greet() {
//
//			@Override
//			public void doGreet() {
//				System.out.println("Good Morninbg :) ");
//			}
//		};
//		Greet goodAfternoonGreet = new Greet() {
//
//			@Override
//			public void doGreet() {
//				System.out.println("Good Afternoon :) ");
//			}
//		};
		
		Greet morning = () -> System.out.println("Good Moning");
		Greet afternoon = () -> System.out.println("Good Afternoon");
		Greet night = () -> System.out.println("Good Night");

		GreetingsApp greetingsApp = new GreetingsApp(morning);
		greetingsApp.printGreetMessage();

	}

}
