package com.accelya.main;

public interface MyInterface {
	public void display();
}
