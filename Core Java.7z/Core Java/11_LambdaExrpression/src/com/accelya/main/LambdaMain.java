package com.accelya.main;

public class LambdaMain {
	public static void main(String[] args) {
//		StringDemoInterface stringDemoInterface = (String text) -> {
//			return text.length();
//		};

//		StringDemoInterface stringDemoInterface = (s) -> {
//			return s.length();
//		};

		StringDemoInterface stringDemoInterface = (s) -> s.length();
		System.out.println(stringDemoInterface.getLength("Hi"));

		System.out.println();

		print((s) -> s.length());
		System.out.println();
		printTwo((s) -> s.toUpperCase());
		printTwo((s) -> s.toLowerCase());
		printTwo((s) -> s.repeat(5));

	}

	public static void print(StringDemoInterface demoInterface) {
		System.out.println(demoInterface.getLength("Hi"));
	}

	public static void printTwo(StringInterface stringInterface) {
		System.out.println(stringInterface.stringOperations("Hi"));
	}

	interface StringInterface {
		String stringOperations(String text);
	}

	interface StringDemoInterface {
		int getLength(String text);
	}
}
