package com.accelya.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;

import com.accelya.main.domain.Person;

public class PersonMainJava7 {

	public static void main(String[] args) {
		Person[] persons = { new Person("Vivek", "Gohil", 33), new Person("Trupti", "Acharekar", 38),
				new Person("Gurubux", "Gill", 26), new Person("Samrth", "Patil", 6) };

		List<Person> people = Arrays.asList(persons);

//		Comparator<Person> sortByLastName = new Comparator<Person>() {
//
//			@Override
//			public int compare(Person person1, Person person2) {
//				return person1.getLastName().compareTo(person2.getLastName());
//			}
//
//		};
		// Collections.sort(people, sortByLastName);
		// 1. Sort the list by last name
		Collections.sort(people, new Comparator<Person>() {
			@Override
			public int compare(Person person1, Person person2) {
				return person1.getLastName().compareTo(person2.getLastName());
			}
		});

		// 2. Create a method that prints all people
		// printAll(people);
		printConditionally(people, new Conditions() {

			@Override
			public boolean test(Person person) {
				return true;
			}
		});
		System.out.println();
		// 3. Create a method that prints all people that have last name
		// begining with G
		// printAllLastNameStartsWithG(people);
		Conditions startsWithG = new Conditions() {

			@Override
			public boolean test(Person person) {
				if (person.getLastName().startsWith("G"))
					return true;
				else
					return false;
			}
		};

		printConditionally(people, startsWithG);
		System.out.println();
		// 4. Create a method that prints all people that have last name
		// ending with L
		// printAllLastNameEndsWithL(people);

	}

//	public static void printAll(List<Person> people) {
//		for (Person person : people) {
//			System.out.println(person);
//		}
//	}

	public static void printConditionally(List<Person> people, Conditions condition) {
		for (Person person : people) {
			if (condition.test(person)) {
				System.out.println(person);
			}
		}
	}

	interface Conditions {
		boolean test(Person person);
	}

//	public static void printAllLastNameStartsWithG(List<Person> people) {
//		for (Person person : people) {
//			if (person.getLastName().startsWith("G")) {
//				System.out.println(person);
//			}
//		}
//	}
//
//	public static void printAllLastNameEndsWithL(List<Person> people) {
//		for (Person person : people) {
//			if (person.getLastName().endsWith("l")) {
//				System.out.println(person);
//			}
//		}
//	}

}
