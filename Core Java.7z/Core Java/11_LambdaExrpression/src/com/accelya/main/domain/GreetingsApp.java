package com.accelya.main.domain;

public class GreetingsApp {
	private Greet greet;

	public GreetingsApp(Greet greet) {
		super();
		this.greet = greet;
	}

	public void printGreetMessage() {
		greet.doGreet();
	}
}
