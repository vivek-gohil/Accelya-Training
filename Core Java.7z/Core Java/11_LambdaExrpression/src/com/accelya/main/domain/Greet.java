package com.accelya.main.domain;

public interface Greet {
	void doGreet();
}
