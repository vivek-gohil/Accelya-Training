package com.accelya.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;

import com.accelya.main.PersonMainJava7.Conditions;
import com.accelya.main.domain.Person;

public class PersonMainJava8 {

	public static void main(String[] args) {
		Person[] persons = { new Person("Vivek", "Gohil", 33), new Person("Trupti", "Acharekar", 38),
				new Person("Gurubux", "Gill", 26), new Person("Samrth", "Patil", 6) };

		List<Person> people = Arrays.asList(persons);

		// Sort by last name
		Collections.sort(people, (p1, p2) -> p1.getLastName().compareTo(p2.getLastName()));

		// print all
		printConditionally(people, p -> true);

		// last name starts with G
		printConditionally(people, p -> p.getLastName().startsWith("G"));

		// last name ends with L
		printConditionally(people, p -> p.getLastName().endsWith("l"));

	}

	public static void printConditionally(List<Person> people, Predicate<Person> condition) {
		for (Person person : people) {
			if (condition.test(person)) {
				System.out.println(person);
			}
		}
	}

}
