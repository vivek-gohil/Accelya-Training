package com.accelya.main;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.accelya.main.domain.Person;
import com.accelya.main.domain.SortByFirstName;

public class DataMain {
	public static void main(String[] args) {
		String[] names = { "Hassan", "Utkarsh", "Suman", "Ahmad", "Jitendra", "Ayush", "Hussain", "Sahil", "Vishal",
				"Shivam" };
		// Arrays.sort(names);

		for (String name : names) {
			System.out.println(name);
		}

		System.out.println("-----------------------------");

		List<String> people = Arrays.asList(names);
		Collections.sort(people);
		for (String name : people) {
			System.out.println(name);
		}

		System.out.println("-----------------------------");

		Person[] persons = { new Person("Vivek", "Gohil", 33), new Person("Trupti", "Acharekar", 38),
				new Person("Gurubux", "Gill", 26), new Person("Samrth", "Patil", 6) };

		// Arrays.sort(persons);
		Arrays.sort(persons, new SortByFirstName());

		System.out.println(Arrays.asList(persons));

	}
}
