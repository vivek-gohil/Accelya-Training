package com.accelya.main;

import java.util.List;
import java.util.Scanner;

import com.accelya.main.domain.BookDetails;
import com.accelya.main.service.BookDetailsService;
import com.accelya.main.service.BookDetailsServiceInterface;

public class BookDetailsMain {
	public static void main(String[] args) {
		int choice;
		int bookID = 0, availableCount = 0;
		double price = 0;
		String title = "", author = "";
		boolean issueable = false;
		String loopChoice = null;
		Scanner scanner = new Scanner(System.in);

		BookDetails bookDetails = new BookDetails();
		// BookDetailsRepository bookDetailsRepository = new BookDetailsRepository();
		BookDetailsServiceInterface bookDetailsService = new BookDetailsService();

		do {
			System.out.println("Menu :");
			System.out.println("1. Add New Book.");
			System.out.println("2. Update Existing Book Title and Author.");
			System.out.println("3. Update Existing Available Book Count.");
			System.out.println("4. Delete Existing Book.");
			System.out.println("5. Print Single book Details.");
			System.out.println("6. Print All book Details.");
			System.out.println("Enter your Choice :");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter New Book Title :");
				title = scanner.next();
				System.out.println("Enter New Book Author :");
				author = scanner.next();
				System.out.println("Enter New Book Price :");
				price = scanner.nextDouble();
				System.out.println("Is Book is Issuable?(true or false):");
				issueable = scanner.nextBoolean();
				System.out.println("Enter New book available count :");
				availableCount = scanner.nextInt();
				bookDetails = new BookDetails(bookID, title, author, price, issueable, availableCount);
				if (bookDetailsService.addNewBookDetails(bookDetails)) {
					System.out.println("-------------------");
					System.out.println("New Book Added.");
					System.out.println("-------------------");
				} else {

					System.out.println("----------");
					System.out.println("Not Added.");
					System.out.println("----------");
				}
				break;
			case 2:
				System.out.println("Enter Book ID to be updated :");
				bookID = scanner.nextInt();
				System.out.println("Enter New Book Title :");
				scanner.nextLine();
				title = scanner.next();

				System.out.println("Enter New Book author :");
				author = scanner.next();
				bookDetails = new BookDetails(bookID, title, author, price, issueable, availableCount);
				if (bookDetailsService.updateBookTitleAndAuthor(bookDetails)) {
					System.out.println("-------------------");
					System.out.println("Book Author and Title Updated.");
					System.out.println("-------------------");
				} else {

					System.out.println("----------");
					System.out.println("Not Updated.");
					System.out.println("----------");
				}
				break;
			case 3:
				System.out.println("Enter Book ID whose count to be updated :");
				bookID = scanner.nextInt();
				System.out.println("Enter New Count of Book :");
				availableCount = scanner.nextInt();
				bookDetails = new BookDetails(bookID, title, author, price, issueable, availableCount);
				if (bookDetailsService.updateBookAvailableCount(bookDetails)) {
					System.out.println("-------------------");
					System.out.println("Book Count Updated.");
					System.out.println("-------------------");
				} else {

					System.out.println("----------");
					System.out.println("Not Updated.");
					System.out.println("----------");
				}
				break;
			case 4:
				System.out.println("Enter Book ID to be deleted :");
				bookID = scanner.nextInt();
				if (bookDetailsService.deleteBookDetails(bookID)) {
					System.out.println("-------------------");
					System.out.println("Book Deleted.");
					System.out.println("-------------------");
				} else {

					System.out.println("----------");
					System.out.println("Not Deleted.");
					System.out.println("----------");
				}
				break;
			case 5:
				System.out.println("Enter Book ID to be viewed :");
				bookID = scanner.nextInt();
				bookDetails = bookDetailsService.getSinlgeBookDetails(bookID);
				if (bookDetails == null) {
					System.out.println("-----------");
					System.out.println("No Record.");
					System.out.println("-----------");
				} else {

					System.out.println("----------");
					System.out.println(bookDetails);
					System.out.println("----------");
				}
				break;
			case 6:
				List<BookDetails> bookList = bookDetailsService.getAllBookDetails();
				if (bookList.size() > 0)
					System.out.println(bookDetailsService.getAllBookDetails());
				else
					System.out.println("No record found.");

				break;
			}
			System.out.println("**************************");
			System.out.println("Do you want to continue? :");
			loopChoice = scanner.next();

		} while (loopChoice.equalsIgnoreCase("yes"));
		scanner.close();

	}
}
