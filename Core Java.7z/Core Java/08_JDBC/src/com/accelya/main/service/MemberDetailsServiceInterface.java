package com.accelya.main.service;

import com.accelya.main.domain.MemberDetails;

public interface MemberDetailsServiceInterface {
	MemberDetails getMemberDetails(int memberId);

	boolean updateBookIssueCount(MemberDetails memberDetails);
}
