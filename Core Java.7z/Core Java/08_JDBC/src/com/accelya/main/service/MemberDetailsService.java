package com.accelya.main.service;

import com.accelya.main.domain.MemberDetails;

public class MemberDetailsService implements MemberDetailsServiceInterface {

	@Override
	public MemberDetails getMemberDetails(int memberId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBookIssueCount(MemberDetails memberDetails) {
		// TODO Auto-generated method stub
		return false;
	}

}
