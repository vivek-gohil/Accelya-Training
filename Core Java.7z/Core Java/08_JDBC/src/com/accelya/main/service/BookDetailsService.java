package com.accelya.main.service;

import java.util.List;

import com.accelya.main.domain.BookDetails;
import com.accelya.main.repository.BookDetailsRepository;
import com.accelya.main.repository.BookDetailsRepositoryInterface;

public class BookDetailsService implements BookDetailsServiceInterface {

	private BookDetailsRepositoryInterface bookDetailsRepository = new BookDetailsRepository();

	@Override
	public boolean addNewBookDetails(BookDetails bookdetails) {
		return bookDetailsRepository.addNewBookDetails(bookdetails);
	}

	@Override
	public boolean updateBookTitleAndAuthor(BookDetails bookdetails) {
		return bookDetailsRepository.updateBookTitleAndAuthor(bookdetails);
	}

	@Override
	public boolean updateBookAvailableCount(BookDetails bookdetails) {
		return bookDetailsRepository.updateBookAvailableCount(bookdetails);
	}

	@Override
	public boolean deleteBookDetails(int bookId) {
		return bookDetailsRepository.deleteBookDetails(bookId);
	}

	@Override
	public BookDetails getSinlgeBookDetails(int bookId) {
		return bookDetailsRepository.getSinlgeBookDetails(bookId);
	}

	@Override
	public List<BookDetails> getAllBookDetails() {
		return bookDetailsRepository.getAllBookDetails();
	}

}
