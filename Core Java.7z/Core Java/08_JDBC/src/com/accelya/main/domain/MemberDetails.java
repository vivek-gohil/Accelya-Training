package com.accelya.main.domain;

public class MemberDetails {
	private int memberId;
	private String firstName;
	private String lastName;
	private char typeOfMember;
	private int bookIssueCount;

	public MemberDetails() {
		// TODO Auto-generated constructor stub
	}

	public MemberDetails(int memberId, String firstName, String lastName, char typeOfMember, int bookIssueCount) {
		super();
		this.memberId = memberId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.typeOfMember = typeOfMember;
		this.bookIssueCount = bookIssueCount;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public char getTypeOfMember() {
		return typeOfMember;
	}

	public void setTypeOfMember(char typeOfMember) {
		this.typeOfMember = typeOfMember;
	}

	public int getBookIssueCount() {
		return bookIssueCount;
	}

	public void setBookIssueCount(int bookIssueCount) {
		this.bookIssueCount = bookIssueCount;
	}

	@Override
	public String toString() {
		return "MemberDetails [memberId=" + memberId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", typeOfMember=" + typeOfMember + ", bookIssueCount=" + bookIssueCount + "]";
	}

}
