package com.accelya.main.domain;

import java.time.LocalDate;

public class BookIssueDetails {
	private int bookIssueId;
	private MemberDetails memberDetails;
	private BookDetails bookDetails;
	private LocalDate issueDate;
	private LocalDate returnDate;

	public BookIssueDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookIssueDetails(int bookIssueId, MemberDetails memberDetails, BookDetails bookDetails, LocalDate issueDate,
			LocalDate returnDate) {
		super();
		this.bookIssueId = bookIssueId;
		this.memberDetails = memberDetails;
		this.bookDetails = bookDetails;
		this.issueDate = issueDate;
		this.returnDate = returnDate;
	}

	public int getBookIssueId() {
		return bookIssueId;
	}

	public void setBookIssueId(int bookIssueId) {
		this.bookIssueId = bookIssueId;
	}

	public MemberDetails getMemberDetails() {
		return memberDetails;
	}

	public void setMemberDetails(MemberDetails memberDetails) {
		this.memberDetails = memberDetails;
	}

	public BookDetails getBookDetails() {
		return bookDetails;
	}

	public void setBookDetails(BookDetails bookDetails) {
		this.bookDetails = bookDetails;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	@Override
	public String toString() {
		return "BookIssueDetails [bookIssueId=" + bookIssueId + ", memberDetails=" + memberDetails + ", bookDetails="
				+ bookDetails + ", issueDate=" + issueDate + ", returnDate=" + returnDate + "]";
	}

}
