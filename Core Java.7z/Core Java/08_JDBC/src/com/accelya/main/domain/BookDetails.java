package com.accelya.main.domain;

public class BookDetails {
	private int bookId;
	private String title;
	private String author;
	private double price;
	private boolean issuable;
	private int availableCount;

	public BookDetails() {
		// TODO Auto-generated constructor stub
	}

	public BookDetails(int bookId, String title, String author, double price, boolean issuable, int availableCount) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.price = price;
		this.issuable = issuable;
		this.availableCount = availableCount;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public boolean isIssuable() {
		return issuable;
	}

	public void setIssuable(boolean issuable) {
		this.issuable = issuable;
	}

	public int getAvailableCount() {
		return availableCount;
	}

	public void setAvailableCount(int availableCount) {
		this.availableCount = availableCount;
	}

	@Override
	public String toString() {
		return "BookDetails [bookId=" + bookId + ", title=" + title + ", author=" + author + ", price=" + price
				+ ", issuable=" + issuable + ", availableCount=" + availableCount + "]";
	}

}
