package com.accelya.main.repository;

import com.accelya.main.domain.MemberDetails;

public interface MemberDetailsRepositoryInterface {
	MemberDetails getMemberDetails(int memberId);

	boolean updateBookIssueCount(MemberDetails memberDetails);
}
