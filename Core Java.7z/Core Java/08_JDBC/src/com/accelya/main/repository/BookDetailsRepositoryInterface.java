package com.accelya.main.repository;

import java.util.List;

import com.accelya.main.domain.BookDetails;

public interface BookDetailsRepositoryInterface {
	public boolean addNewBookDetails(BookDetails bookdetails);

	public boolean updateBookTitleAndAuthor(BookDetails bookdetails);

	public boolean updateBookAvailableCount(BookDetails bookdetails);

	public boolean deleteBookDetails(int bookId);

	public BookDetails getSinlgeBookDetails(int bookId);

	public List<BookDetails> getAllBookDetails();
}
