package com.accelya.main.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.accelya.main.domain.BookDetails;

public class BookDetailsRepository implements BookDetailsRepositoryInterface {
	public boolean addNewBookDetails(BookDetails bookdetails) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int count;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "insert into vivek_book_details(title,author,price,issueable,available_count) values (?,?,?,?,?)";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, bookdetails.getTitle());
			preparedStatement.setString(2, bookdetails.getAuthor());
			preparedStatement.setDouble(3, bookdetails.getPrice());
			preparedStatement.setBoolean(4, bookdetails.isIssuable());
			preparedStatement.setInt(5, bookdetails.getAvailableCount());

			count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return false;
	}

	public boolean updateBookTitleAndAuthor(BookDetails bookdetails) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int count;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "update vivek_book_details set title=?,author=? where book_id = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setString(1, bookdetails.getTitle());
			preparedStatement.setString(2, bookdetails.getAuthor());
			preparedStatement.setInt(3, bookdetails.getBookId());

			count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return false;
	}

	public boolean updateBookAvailableCount(BookDetails bookdetails) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int count;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "update vivek_book_details set available_count=? where book_id = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, bookdetails.getAvailableCount());
			preparedStatement.setInt(2, bookdetails.getBookId());

			count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return false;
	}

	public boolean deleteBookDetails(int bookId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		int count;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "delete from vivek_book_details where book_id=?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, bookId);

			count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return false;
	}

	public BookDetails getSinlgeBookDetails(int bookId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		BookDetails bookDetails = new BookDetails();
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "select * from vivek_book_details where book_id=?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, bookId);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				bookDetails = new BookDetails(resultSet.getInt("book_id"), resultSet.getString("title"),
						resultSet.getString("author"), resultSet.getDouble("price"), resultSet.getBoolean("issueable"),
						resultSet.getInt("available_count"));
				return (bookDetails);
			} else {
				System.out.println("No rows Found!!");
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return (bookDetails);

	}

	public List<BookDetails> getAllBookDetails() {
		List<BookDetails> bookList = new ArrayList<>();
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		BookDetails bookDetails = new BookDetails();
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "select * from vivek_book_details";
			preparedStatement = connection.prepareStatement(sql);

			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				bookDetails = new BookDetails(resultSet.getInt("book_id"), resultSet.getString("title"),
						resultSet.getString("author"), resultSet.getDouble("price"), resultSet.getBoolean("issueable"),
						resultSet.getInt("available_count"));
				bookList.add(bookDetails);
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return (bookList);
	}

}
