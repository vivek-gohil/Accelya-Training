package com.accelya.main.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.accelya.main.domain.BookDetails;
import com.accelya.main.domain.MemberDetails;

public class MemberDetailsRepository implements MemberDetailsRepositoryInterface {

	@Override
	public MemberDetails getMemberDetails(int memberId) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;
		MemberDetails memberDetails = null;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			System.out.println("Connection Succesfull");
			sql = "select * from member_details where member_id=?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, memberId);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				memberDetails = new MemberDetails();
				memberDetails.setMemberId(resultSet.getInt("member_id"));
				memberDetails.setFirstName(resultSet.getString("first_name"));
				memberDetails.setFirstName(resultSet.getString("last_name"));
				memberDetails.setTypeOfMember(resultSet.getString("member_type").charAt(0));
				memberDetails.setBookIssueCount(resultSet.getInt("book_issue_count"));
				return memberDetails;
			} else {
				return null;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return memberDetails;
	}

	@Override
	public boolean updateBookIssueCount(MemberDetails memberDetails) {
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		int count;
		String sql = "";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			connection = DriverManager.getConnection("jdbc:oracle:thin:@10.23.3.140:1548:REVEIDEV", "MIGR_OWNER",
					"ebaF#2dj");
			sql = "update member_details set book_issue_count = book_issue_count + 1 where member_code = ?";
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setInt(1, memberDetails.getMemberId());

			count = preparedStatement.executeUpdate();
			if (count > 0) {
				return true;
			} else {
				return false;
			}

		} catch (ClassNotFoundException e) {
			System.out.println("Exception while loading driver classs : " + e.getMessage());
		} catch (SQLException e) {
			System.out.println("Exception while connecting Oracle database :" + e.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				System.out.println("Exception while closing connection : " + e.getMessage());
			}
		}
		return false;
	}

}
